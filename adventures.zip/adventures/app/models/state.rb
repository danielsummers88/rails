class State < ApplicationRecord
end
